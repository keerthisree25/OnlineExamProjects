package com.exam.dto;

import javax.persistence.ManyToOne;

import com.exam.model.User;



public class UserRoleDTO {
	
 private long userRoleId;
 private User user;
 private User role;
 
 }
